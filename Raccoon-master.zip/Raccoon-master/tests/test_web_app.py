import unittest


class Cookie:

    def __init__(self):
        pass


class Response:
    headers = {}


class TestWebApplicationScanner(unittest.TestCase):

    def setUp(self):
        # cookie_jar = []
        pass

