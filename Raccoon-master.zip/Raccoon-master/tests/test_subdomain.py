import unittest


class TestSubDomainEnumerator(unittest.TestCase):

    def setUp(self):
        # SANs = []
        pass


