//
//  WeScan.h
//  WeScan
//
//  Created by Boris Emorine on 2/8/18.
//  Copyright © 2018 WeTransfer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Scanner.
FOUNDATION_EXPORT double ScannerVersionNumber;

//! Project version string for Scanner.
FOUNDATION_EXPORT const unsigned char ScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Scanner/PublicHeader.h>
